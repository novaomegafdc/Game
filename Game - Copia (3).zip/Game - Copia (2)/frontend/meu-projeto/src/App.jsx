import { useState, useEffect } from 'react';
import './App.css';

function App() {
  const [jogos, setJogos] = useState(() => {
    const salvos = localStorage.getItem('meus_jogos');

    return salvos
      ? JSON.parse(salvos)
      : [
          { id: 1, titulo: 'Mario', plataforma: 'Pc' },
          { id: 2, titulo: 'The witcher 3', plataforma: 'Xbox' },
        ];
  });

  const [novoJogo, setNovoJogo] = useState('');
  const [plataforma, setPlataforma] = useState('');
  const [termoPesquisa, setTermoPesquisa] = useState('');

  useEffect(() => {
    localStorage.setItem('meus_jogos', JSON.stringify(jogos));
  }, [jogos]);

  const adicionarJogo = (e) => {
    e.preventDefault();

    if (!novoJogo.trim()) return;

    const jogoCriado = {
      id: Date.now(),
      titulo: novoJogo,
      plataforma: plataforma || 'PC',
    };

    setJogos([...jogos, jogoCriado]);
    setNovoJogo('');
    setPlataforma('');
  };

  const deletarJogo = (id) => {
    setJogos(jogos.filter((jogo) => jogo.id !== id));
  };

  const jogosFiltrados = jogos.filter(
    (jogo) =>
      jogo.titulo.toLowerCase().includes(termoPesquisa.toLowerCase()) ||
      jogo.plataforma.toLowerCase().includes(termoPesquisa.toLowerCase())
  );

  return (
    <div className="app">
      <div className="container">

        {/* CABEÇALHO */}
        <header className="header">
          <div className="logo-area">
            <div className="logo-icon">🎮</div>

            <div>
              <h1>Game Library</h1>
              <p>Gerencie seus jogos favoritos</p>
            </div>
          </div>

          <div className="contador">
            <span>{jogos.length}</span>
            <small>jogos</small>
          </div>
        </header>

        {/* PESQUISA */}
        <section className="search-area">
          <div className="search-box">
            <span>🔍</span>

            <input
              type="text"
              placeholder="Pesquisar por jogo ou plataforma..."
              value={termoPesquisa}
              onChange={(e) => setTermoPesquisa(e.target.value)}
            />
          </div>
        </section>

        {/* FORMULÁRIO */}
        <section className="add-section">
          <div className="section-title">
            <h2>Adicionar novo jogo</h2>
            <p>Cadastre um novo jogo na sua biblioteca.</p>
          </div>

          <form onSubmit={adicionarJogo} className="form">

            <div className="input-group">
              <label>Nome do jogo</label>

              <input
                type="text"
                placeholder="Ex: God of War"
                value={novoJogo}
                onChange={(e) => setNovoJogo(e.target.value)}
              />
            </div>

            <div className="input-group">
              <label>Plataforma</label>

              <input
                type="text"
                placeholder="Ex: PC, PS5, Xbox..."
                value={plataforma}
                onChange={(e) => setPlataforma(e.target.value)}
              />
            </div>

            <button type="submit" className="add-button">
              <span>＋</span>
              Adicionar jogo
            </button>

          </form>
        </section>

        {/* LISTA */}
        <section className="games-section">

          <div className="section-header">
            <div>
              <h2>Minha biblioteca</h2>
              <p>
                {jogosFiltrados.length}{' '}
                {jogosFiltrados.length === 1 ? 'jogo encontrado' : 'jogos encontrados'}
              </p>
            </div>
          </div>

          {jogosFiltrados.length > 0 ? (
            <div className="games-list">

              {jogosFiltrados.map((jogo) => (
                <div className="game-card" key={jogo.id}>

                  <div className="game-icon">
                    🎮
                  </div>

                  <div className="game-info">
                    <h3>{jogo.titulo}</h3>

                    <div className="platform">
                      <span>▣</span>
                      {jogo.plataforma}
                    </div>
                  </div>

                  <button
                    className="delete-button"
                    onClick={() => deletarJogo(jogo.id)}
                    title="Excluir jogo"
                  >
                    🗑
                  </button>

                </div>
              ))}

            </div>
          ) : (
            <div className="empty">

              <div className="empty-icon">
                🔎
              </div>

              <h3>Nenhum jogo encontrado</h3>

              <p>
                Tente pesquisar por outro nome ou plataforma.
              </p>

            </div>
          )}

        </section>

        {/* RODAPÉ */}
        <footer>
          <p>🎮 Game Library • Sua coleção de jogos</p>
        </footer>

      </div>
    </div>
  );
}

export default App;