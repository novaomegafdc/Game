from django.db import models

class Jogo(models.Model):
    titulo = models.CharField(max_length=100)
    plataforma = models.CharField(max_length=50, default="PC")
    concluido = models.BooleanField(default=False)

    def __str__(self):
        return self.titulo